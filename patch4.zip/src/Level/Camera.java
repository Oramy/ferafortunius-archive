package Level;

import ObjetMap.ObjetMap;

public class Camera {
	private float zoom;
	private int x; 
	private	int y;
	private long camSpeed;
	private long lastMove;
	/**
	 * l'objet � suivre
	 */
	private ObjetMap followHim;
	private CameraStatus status;
	private int destX;
	private int destY;
	private long timeToDest, beginTime;
	public Camera(int x, int y, float zoom){
		this.zoom = zoom;
		this.x = x;
		this.y = y;
		status = CameraStatus.Stopped;
		camSpeed = 1;
		lastMove = System.currentTimeMillis();
	}
	public Camera(int x, int y){
		this.x = x;
		this.y = y;
		status = CameraStatus.Stopped;
		camSpeed = 1;
		lastMove = System.currentTimeMillis();
	}
	public void move(float x, float  y){
		this.x += x;
		this.y += y;
	}
	public int getMovesNumber(int destX, int destY){
		int movesX, movesY;
		movesX = (int) (x - destX);
		if(movesX < 0)
			movesX = -movesX;
		movesY = (int) (y - destY);
		if(movesY < 0)
			movesY = -movesY;
		if(movesX > movesY)
			return movesX;
		return movesY;
	}
	public void moveToObject(int posX, int posY, int posZ, int moveSize){
		int x = (posX - posY);
		int y = -(posX + posY) / 2 - posZ;
		float difx = this.x - x;
		if(difx < 0)
			difx = -difx;
		float dify = this.y - y;
		if(dify < 0)
			dify = -dify;
		float bigger = difx;
		if(difx < dify)
			bigger = dify;
		if(this.x != x){
			if(this.x > x){
				this.x-= difx / bigger * moveSize;
				if(this.x < x)
					this.x = x;				
			}
			else
			{
				this.x+= difx / bigger *moveSize;
				if(this.x > x)
					this.x = x;
			}
		}
		if(this.y != y){
			if(this.y > y){
				this.y-= dify / bigger * moveSize;
				if(this.y < y)
					this.y = y;
			}
			else
			{
				this.y+= dify / bigger * moveSize;
				if(this.y > y)
					this.y = y;
			}
		}
		lastMove = System.currentTimeMillis();
	}
	public void moveToObject(ObjetMap o, int moveSize){
		moveToObject(o.getPosX(), o.getPosY(), o.getPosZ(), moveSize);
	}
	public void teleportToObject(int posX, int posY, int posZ){
		this.x = (posX - posY);
		this.y = -(posX + posY) / 2 - posZ;
	}
	public void teleportToObject(ObjetMap o){
		teleportToObject(o.getPosX(), o.getPosY(), o.getPosZ());
	}
	public void moveAtObject(int x1, int y1, int z1, int time){
		status = CameraStatus.Move;
		destX = x1 - y1;
		destY = -(x1 + y1) / 2 - z1;
		timeToDest = time;
		beginTime = System.currentTimeMillis() + 1;
	}
	//TODO g�rer les chunks avec la cam�ra !
	public void moveAtObject(ObjetMap o, int time){
		moveAtObject(o.getPosX() + o.getSizeX() / 2, o.getPosY() + o.getSizeY() / 2, o.getPosZ() + o.getSizeZ() / 2, time);
	}
	// TODO fonction de la cam�ra plus sophistiqu�s.
	/**
	 * 
	 * @param x position x de la cam�ra voulue
	 * @param y position y de la cam�ra voulue
	 * @param time
	 */
	public void moveAt(int x, int y, int time){
		status = CameraStatus.Move;
		destX = x;
		destY = y;
		timeToDest = time;
		/*while(this.x != x || this.y != y)
		{
			if(this.x != x){
				if(this.x > x){
					this.x--;
				}
				else
				{
					this.x++;
				}
			}
			if(this.y != y){
				if(this.y > y){
					this.y--;
				}
				else
				{
					this.y++;
				}
			}
			try {
				Thread.sleep(time);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}*/
	}
	/**
	 * @return the zoom
	 */
	public float getZoom() {
		return zoom;
	}
	public void update(){
		if(status == CameraStatus.Follow){
			if((System.currentTimeMillis() - lastMove) / camSpeed >= 1)
			moveToObject(followHim, (int) ((System.currentTimeMillis() - lastMove) / camSpeed));
		}
		else if(status == CameraStatus.Move){
			if((this.x == destX && this.y == destY) || ((beginTime + timeToDest - System.currentTimeMillis()) / getMovesNumber(destX, destY)) <= 0)
				status = CameraStatus.Stopped;
			else
			moveToObject((int)destX,
					(int)destY,
					0,
					(int) ((System.currentTimeMillis() - beginTime) / ((beginTime + timeToDest - System.currentTimeMillis()) / getMovesNumber(destX, destY))));
		}
		else if(status == CameraStatus.Show){
			
		}
	}
	/**
	 * @param zoom the zoom to set
	 */
	public void setZoom(float zoom) {
		
		this.zoom = zoom;
		if(this.zoom < 0.01f){
			this.zoom = 0.01f;
		}
		if(this.zoom > 2f){
			this.zoom = 2f;
		}
	}
	/**
	 * @return the x
	 */
	public int getX() {
		return x;
	}
	/**
	 * @param x the x to set
	 */
	public void setX(int x) {
		this.x = x;
	}
	/**
	 * @return the y
	 */
	public int getY() {
		return y;
	}
	/**
	 * @param y the y to set
	 */
	public void setY(int y) {
		this.y = y;
	}
	/**
	 * @return the followHim
	 */
	public ObjetMap getFollowHim() {
		return followHim;
	}
	/**
	 * @param followHim the followHim to set
	 */
	public void setFollowHim(ObjetMap followHim) {
		this.followHim = followHim;
		if(followHim != null)
			status = CameraStatus.Follow;
	}
}
