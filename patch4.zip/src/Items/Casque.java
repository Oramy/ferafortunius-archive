package Items;

import ObjetMap.Entity;

public class Casque extends EquipmentItem {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Casque(Entity owner) {
		super(owner);
	}

}
