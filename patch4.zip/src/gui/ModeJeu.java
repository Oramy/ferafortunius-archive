package gui;

public enum ModeJeu{
	Menu,
	Jeu, 
	Editeur,
}