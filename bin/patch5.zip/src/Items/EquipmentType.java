package Items;

public enum EquipmentType {
	Basic,
	Arme,
	Casque,
	
}
