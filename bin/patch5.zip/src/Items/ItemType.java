package Items;

public enum ItemType {
	Basic, 
	Equipment, 
	Utility, 
	Narrative

}
