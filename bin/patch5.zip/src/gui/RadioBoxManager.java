package gui;

public class RadioBoxManager extends CheckBoxManager{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RadioBoxManager(int x, int y, int sizeX, int sizeY, Container parent) {
		super(x, y, sizeX, sizeY, parent);
		
	}

}
