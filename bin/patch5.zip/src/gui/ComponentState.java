package gui;

public enum ComponentState {
	Normal,
	Hover,
	Clicked,
	Disabled,
}
