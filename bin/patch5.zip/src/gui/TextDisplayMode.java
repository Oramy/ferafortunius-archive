package gui;

import java.io.Serializable;

public enum TextDisplayMode implements Serializable{
	Instantly,
	Slowly,
	Normal,
	Fast
}
