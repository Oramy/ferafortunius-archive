package Level;

public enum CameraStatus {
	Stopped,
	Follow,
	Move,
	Show,
}
