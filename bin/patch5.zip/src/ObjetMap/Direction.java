package ObjetMap;

public enum Direction {
	S, SW, W, NW, N, NE, E, SE,
}
