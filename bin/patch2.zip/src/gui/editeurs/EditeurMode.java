package gui.editeurs;

public enum EditeurMode {
	Placer,
	Ensemble,
	Supprimer,
}
