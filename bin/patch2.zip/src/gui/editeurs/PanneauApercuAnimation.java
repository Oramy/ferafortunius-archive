package gui.editeurs;

import gui.Container;

import org.newdawn.slick.GameContainer;

import Level.ChunkMap;
import ObjetMap.ObjetMap;


public class PanneauApercuAnimation extends PanneauApercu{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public PanneauApercuAnimation(ChunkMap c, ObjetMap obj, int x, int y,
			int sizeX, int sizeY, Container parent) {
		super(obj, x, y, sizeX, sizeY, parent);
		moveImage = false;
		
	}
	public void update(GameContainer gc, int x, int y){
		super.update(gc, x, y);
		this.editChoice.updateAlone(null);
	}
	

}
