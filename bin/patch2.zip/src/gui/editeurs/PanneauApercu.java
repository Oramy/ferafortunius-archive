package gui.editeurs;

import gui.Container;
import gui.PImage;
import gui.jeu.PanneauJeuAmeliore;

import java.util.ArrayList;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.geom.Polygon;

import Level.ArrayIterator;
import Level.ChunkMap;
import Level.Iterator;
import ObjetMap.ObjetImage;
import ObjetMap.ObjetMap;


public class PanneauApercu extends PanneauJeuAmeliore {
	/**
	 * 
	 */
	protected static final long serialVersionUID = 1L;
	protected ObjetMap editChoice;
	protected ObjetImage draggedObjImg;
	protected int oldx;
	protected int oldy;
	protected boolean clicked;
	protected boolean dragged;
	protected boolean moveImage;
 	public PanneauApercu(ObjetMap obj, int x, int y, int sizeX, int sizeY,
			Container parent) {
		super(new ChunkMap(10000000,1,1,1), x, y, sizeX, sizeY, parent);
		editChoice = obj;
		chunkcolor = Color.black;
		moveImage = true;
		dragged = false;
	}
	public void draw(Graphics g){
		draggedObjImg = null;
		g.translate(getX(),getY());
		if(getEditChoice() != null){
			g.translate(this.getWidth()/2, this.getHeight()/2);
				g.translate(-actualCam.getX() * actualCam.getZoom(), -actualCam.getY() * actualCam.getZoom());
				ObjetMap o = getEditChoice();
					if(o != null){
						//Initialisation d'un iterateur
						if(o.getImageList(o.getCurrentImageList()) != null){
							Iterator it2 = o.getImagesIterator();
							ObjetImage objetImg = null;
							//Affichage des images
							do{
								objetImg = (ObjetImage) it2.getNextElement();
								if(objetImg != null){
									PImage imgToDraw = null;
									boolean loadImage = false;
									if(o.getDrawImage() != null){
										
										for(int z = 0; z < o.getDrawImage().size(); z++){
											PImage imageIt = img.get(o.getDrawImage().get(z));
											if(imageIt.getNom().equals(objetImg.getImage())){
												loadImage = true;
												imgToDraw = imageIt;
											}
										}
									}
									else{
										o.setDrawImage(new ArrayList<Integer>());
									}
									if(!loadImage){
										
										boolean inList = false;
										for (int l = 0, l2 = img.size(); l < l2; l++) {
											if (img.get(l).getNom().equals(objetImg.getImage())) {
												if(!o.getDrawImage().contains(l)){
													o.getDrawImage().add(l);
													imgToDraw = img.get(l);
												}
												inList = true;
												l = l2;
											}
										}
										if(!inList){
											PImage toload = new PImage(objetImg.getImage());
											img.add(toload);
											o.getDrawImage().add(img.size() - 1);
											imgToDraw = toload;
										}
									}
	
									Image wildImg = imgToDraw.getImg();
									Image formatImage = wildImg.getSubImage(objetImg.getPosSpriteSheetX(), objetImg.getPosSpriteSheetY(), wildImg.getWidth(), wildImg.getHeight());
									wildImg = formatImage;
									SpriteSheet sprite = new SpriteSheet(wildImg, objetImg.getSizeSpriteX(),  objetImg.getSizeSpriteY());
									Image image =  sprite.getSprite( objetImg.getPosX(),  objetImg.getPosY());
									image.setAlpha(o.getOpacity());
									if(objetImg.isMirror()){
										image = image.getFlippedCopy(true, false);
									}
									translateToObjectImage(g, o, objetImg);
										
										int posX = this.getWidth()/2;
										posX += -actualCam.getX() * actualCam.getZoom();
										posX +=  + (float)(o.getDecalageX());
										int posY = this.getHeight()/2;
										posY += -actualCam.getY() * actualCam.getZoom();
										posY += + (float)(o.getDecalageY());
											
										int mx = (int) (Mouse.getX() - this.getXOnScreen());
										int my = (int) (getRacine().getHeight() - Mouse.getY() - this.getYOnScreen());
										int posImgX = (int) ((float)(+objetImg.getDecalageX() - (float)(objetImg.getImageSizeInGameX() / 2))); 
										int posImgY = (int) ((float)(+objetImg.getDecalageY() - (float)(objetImg.getImageSizeInGameY()))); 
										ObjetImage parentImg = o.getImage(objetImg.getParentAlias());
										while(parentImg != null){
											posImgX += parentImg.getDecalageX();
											posImgY += parentImg.getDecalageY();
											parentImg = o.getImage(parentImg.getParentAlias());
										}
										posImgX *= actualCam.getZoom();
										posImgY *= actualCam.getZoom();
										if(mx > posX + posImgX && mx < posX + posImgX + (float)(objetImg.getImageSizeInGameX()) * actualCam.getZoom()
												&&  my > posY + posImgY && my < posY + + posImgY+ objetImg.getImageSizeInGameY() * actualCam.getZoom()){
											draggedObjImg = objetImg;
										}
										if(isMoveImage()){
											g.setColor(new Color(255,0,0,25));
											
											g.translate(objetImg.getRotationCenterX() * actualCam.getZoom(), objetImg.getRotationCenterY() * actualCam.getZoom());
												g.rotate(1, 1, objetImg.getRotation());
											g.translate(-objetImg.getRotationCenterX() * actualCam.getZoom(), -objetImg.getRotationCenterY() * actualCam.getZoom());
										
											g.fillRoundRect(0,0, objetImg.getImageSizeInGameX() * actualCam.getZoom(), objetImg.getImageSizeInGameY() * actualCam.getZoom(), 10);
											
											g.translate(objetImg.getRotationCenterX() * actualCam.getZoom(), objetImg.getRotationCenterY() * actualCam.getZoom());
												g.rotate(1, 1, -objetImg.getRotation());
											g.translate(-objetImg.getRotationCenterX() * actualCam.getZoom(), -objetImg.getRotationCenterY() * actualCam.getZoom());
											
										}
										o.paintComponent(this, g, image, posX, posY, objetImg, actualCam);
										if(isMoveImage()){
											g.setColor(new Color(0,100,100, 255));
											g.fillRoundRect(objetImg.getRotationCenterX()  * actualCam.getZoom() - 5, objetImg.getRotationCenterY() * actualCam.getZoom() - 5, 10,10,10);
										}
									untranslateToObjectImage(g, o, objetImg);
	
								}
	
							}while(objetImg != null);
						}
					}
					g.setColor(Color.black);
					Polygon p = new Polygon();
					p.addPoint((float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2)))* actualCam.getZoom()),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2))) * actualCam.getZoom() / 2));
					p.addPoint(0, 0);
					p.addPoint((float) (+(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom()),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom() / 2));
					p.addPoint((float) (+(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom()-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2)))* actualCam.getZoom()),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom() / 2 -(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2))) * actualCam.getZoom() / 2));
					
					g.draw(p);
					Polygon p2 = new Polygon();
					p2.addPoint((float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2)))* actualCam.getZoom()),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2))) * actualCam.getZoom() / 2) - getEditChoice().getSizeZ() * actualCam.getZoom());
					p2.addPoint(0, - getEditChoice().getSizeZ() * actualCam.getZoom());
					p2.addPoint((float) (+(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom()),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom() / 2)- getEditChoice().getSizeZ() * actualCam.getZoom());
					p2.addPoint((float) (+(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom()-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2)))* actualCam.getZoom()),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom() / 2 -(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2))) * actualCam.getZoom() / 2)- getEditChoice().getSizeZ() * actualCam.getZoom());
					
					g.draw(p2);
					g.drawLine(0,0, 0, - getEditChoice().getSizeZ() * actualCam.getZoom());
					g.drawLine((float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2)) * actualCam.getZoom())),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2))) * actualCam.getZoom() / 2),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2))) * actualCam.getZoom()),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeY(), 2))) * actualCam.getZoom() / 2) - getEditChoice().getSizeZ() * actualCam.getZoom());
					g.drawLine((float) (+(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom()),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom() / 2),
							(float) (+(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom()),
							(float) (-(Math.sqrt(Math.pow(getEditChoice().getSizeX(), 2))) * actualCam.getZoom() / 2) - getEditChoice().getSizeZ() * actualCam.getZoom());
					this.drawLines(g, o);
					
				g.translate(actualCam.getX() * actualCam.getZoom(), actualCam.getY() * actualCam.getZoom());
			g.translate(-this.getWidth()/2, -this.getHeight()/2);
		}
		g.translate(-getX(),-getY());
	}
	public void update(GameContainer gc, int x, int y){
		if(gc.getInput().getMouseX() >= this.getX() + x
				&& gc.getInput().getMouseX() <= this.getX() + x + getSizeX()
				&& gc.getInput().getMouseY() >= this.getY() + y
				&& gc.getInput().getMouseY() <= this.getY() + y + getSizeY()){
			if(gc.getInput().isMouseButtonDown(Input.MOUSE_RIGHT_BUTTON) && !clicked){
				clicked = true;
				oldx =  gc.getInput().getMouseX();
				oldy =  gc.getInput().getMouseY();
			}
			else if(!gc.getInput().isMouseButtonDown(Input.MOUSE_RIGHT_BUTTON) && clicked){
				clicked = false;
			}
			if(gc.getInput().isMouseButtonDown(Input.MOUSE_LEFT_BUTTON) && !dragged){
				dragged = true;
				oldx =  gc.getInput().getMouseX();
				oldy =  gc.getInput().getMouseY();
			}	
			else if(!gc.getInput().isMouseButtonDown(Input.MOUSE_LEFT_BUTTON) && dragged){
				dragged = false;
			}
			if(gc.getInput().isMouseButtonDown(Input.MOUSE_RIGHT_BUTTON))
			{
					
			
				int newx = gc.getInput().getMouseX();
				int newy = gc.getInput().getMouseY();
				getActualCam().move(oldx - newx, oldy-newy);
				oldx = newx;
				oldy = newy;
				//carte.verifyPosition(editChoice);
			}
			if(dragged)
			{
					
				if(draggedObjImg != null && isMoveImage()){
					int newx = gc.getInput().getMouseX();
					int newy = gc.getInput().getMouseY();
					draggedObjImg.setDecalageX((int) (draggedObjImg.getDecalageX()+(- oldx + newx)));
					draggedObjImg.setDecalageY((int) (draggedObjImg.getDecalageY()+(- oldy + newy)));
					if(parent.getParent().getParent() instanceof EditeurObjetMap){
						((EditeurObjetMap)parent.getParent().getParent()).getImgEditor().setImgToAdd(draggedObjImg);
					}
					oldx = newx;
					oldy = newy;
				}
				//carte.verifyPosition(editChoice);
			}
			int mouse = Mouse.getDWheel();
			if(mouse > 0){
				this.actualCam.setZoom(this.actualCam.getZoom() *1.2f);
			}
			if(mouse < 0){
				this.actualCam.setZoom(this.actualCam.getZoom() / 1.2f);
			}
		}
		super.update(gc, x, y);
	}
	/**
	 * @return the editChoice
	 */
	public ObjetMap getEditChoice() {
		return editChoice;
	}
	/**
	 * @param editChoice the editChoice to set
	 */
	public void setEditChoice(ObjetMap editChoice) {
		this.editChoice = editChoice;
	}

	/**
	 * @return the moveImage
	 */
	public boolean isMoveImage() {
		return moveImage;
	}

	/**
	 * @param moveImage the moveImage to set
	 */
	public void setMoveImage(boolean moveImage) {
		this.moveImage = moveImage;
	}
}
