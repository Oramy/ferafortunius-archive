package Items;

import ObjetMap.Entity;

public abstract class Bouclier extends Arme {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3357869189134414641L;

	public Bouclier(Entity owner) {
		super(owner);
		
	}

}
