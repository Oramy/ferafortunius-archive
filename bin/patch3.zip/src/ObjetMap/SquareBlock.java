package ObjetMap;

public class SquareBlock {

}
