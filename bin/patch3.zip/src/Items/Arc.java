package Items;

import ObjetMap.Entity;

public class Arc extends Arme {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6920000095135819822L;

	public Arc(Entity owner) {
		super(owner);
		
	}

}
