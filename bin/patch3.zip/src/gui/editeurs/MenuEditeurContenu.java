package gui.editeurs;

import gui.Container;

public class MenuEditeurContenu extends Container{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MenuEditeurContenu(int x, int y, int sizeX, int sizeY,
			Container parent) {
		super(x, y, sizeX, sizeY, parent);
		
	}

}
