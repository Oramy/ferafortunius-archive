package script;

public abstract class FramScript {
	public void addArgument(){
		
	}
}
