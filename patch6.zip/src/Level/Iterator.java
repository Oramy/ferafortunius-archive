package Level;


public interface Iterator {
	 public Object getNextElement();
}
