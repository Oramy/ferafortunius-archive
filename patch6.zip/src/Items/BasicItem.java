package Items;

import ObjetMap.Entity;

public class BasicItem extends Item {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4696532987146618119L;

	public BasicItem(Entity owner) {
		super(owner);
	}

}
