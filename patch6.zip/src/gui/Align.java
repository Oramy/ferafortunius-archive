package gui;

public enum Align {
	Left,
	Center,
	Right
}
