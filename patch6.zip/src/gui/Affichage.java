package gui;

public enum Affichage {
	Normal, ImageBrute, ImageScaled
}
